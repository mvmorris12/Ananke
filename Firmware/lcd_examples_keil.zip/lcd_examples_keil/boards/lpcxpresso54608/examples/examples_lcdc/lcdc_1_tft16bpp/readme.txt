Overview
========
The lcdc_tft example shows how to use LCD driver to drive TFT panel.

In this example, the cursor palette is used. A rectangle is shown in the panel,
its color and position are changed every frame.

Toolchain supported
===================
- Keil MDK 5.20

Hardware requirements
=====================
- Micro USB cable
- LPCXpresso54608 board
- Personal Computer

Board settings
==============
No special board settings.

Prepare the Demo
================
1. Connect a micro USB cable between the PC host and the LPC-Link USB port (J8) on the board.
2. Download the program to the target board.
3. Either press the reset button on your board or launch the debugger in your IDE to begin running
   the demo.

Running the demo
================
Description��Initializes LCD controller, SDRAM, and draw on framebuffer
Result: 8 color stripes moving on LCD screen

Customize options
=====================
Change the color of stripes by modifying ��colTab�� array.
Change panel clock frequency macro ��LCD_PANEL_CLK��, suggested range 4-16 MHz
Learn the members of ��lcdc_config_t��, how they map to LCD controller to registers.
Check the ��Flash.sct�� and the definition of ��s_FB�� to see how to make framebuffer placed into SDRAM w/o involving compiler to generate initialization code before main().
Otherwise, w/o SDRAM initialized, accessing SDRAM will cause hard fault.

