Overview
========
The lcdc_tft example shows how to use LCD driver to drive TFT panel.

In this example, the cursor palette is used. A rectangle is shown in the panel,
its color and position are changed every frame.

Toolchain supported
===================
- Keil MDK 5.20

Hardware requirements
=====================
- Micro USB cable
- LPCXpresso54608 board
- Personal Computer

Board settings
==============
No special board settings.

Prepare the Demo
================
1. Connect a micro USB cable between the PC host and the LPC-Link USB port (J8) on the board.
2. Download the program to the target board.
3. Either press the reset button on your board or launch the debugger in your IDE to begin running
   the demo.

Running the demo
================
Description�� Repeating drawings in main loop: first clear the screen to black, then draw color stripes.  Use SysTick timer to limit draw rate. 
If ��SW5�� is not pressed, then use one FB to draw, 
if ��SW5�� is pressed, then waits for ��base address update�� IRQ, then draws on backup FB (the previous active FB), after drawing, set the next active FB to this FB.
Result: If ��SW5�� is not pressed, then black screen and color stripes shows on screen interleaved, get flicker feeling; if ��SW5�� is pressed, only the rotating color stripes are showed (like HOT1).

Customize options
=====================
Change SysTick rate, check if it can resolve the flicker effect w/o dual-FB, and/or affects dual-FB effect.
Comment out the ��while (!s_frameAddrUpdated){}��, see if it affects dual-FB effect.
Switch stage1 and stage2, check the differences of LCD display for single FB and dual-FB respectively.

